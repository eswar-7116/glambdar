exports.handler = async (req) => {
    const { headers, json, body } = req;
    let jsonData;
    if (headers['Content-Type'] === 'application/json') {
        jsonData = await json();
    }

    return {
        statusCode: 200,
        body: {
            headers,
            string: body,
            json: jsonData
        }
    }
}