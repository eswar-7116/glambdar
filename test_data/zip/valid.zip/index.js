exports.handler = async (req) => {
    const { headers, body, method } = req;
    let jsonData;
    const contentType = (headers || {})['Content-Type'] || (headers || {})['content-type'];
    if (contentType === 'application/json') {
        try {
            jsonData = await req.json();
        } catch (e) {
            console.error("failed override json", e);
        }
    }

    return {
        statusCode: 200,
        body: {
            method: method,
            string: body,
            json: jsonData
        }
    };
};
