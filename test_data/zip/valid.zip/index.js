exports.handler = async (req) => {
    console.log(req)
    const { headers, body } = req;
    let jsonData;
    console.log(headers);
    if (headers['Content-Type'] === 'application/json') {
        jsonData = await req.json();
    }

    return {
        statusCode: 200,
        body: {
            string: body,
            json: jsonData
        }
    }
}
