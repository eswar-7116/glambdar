exports.handler = async (req) => {
    const { headers, json, body } = req;
    let jsonData;
    if (headers['Content-Type'] === 'application/json') {
        jsonData = await json();
    }

    return {
        statusCode: 200,
        headers,
        body: {
            string: body,
            json: jsonData
        }
    }
}
